﻿addappid(1790930) -- Crisol: Theater of Idols
addappid(1790931, 1, "1004ecdf80e18a409de92e25b9422c289ffae11c70dc4480fcb2ac76f4f77f39") -- Depot 1790931
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
