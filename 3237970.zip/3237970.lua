﻿addappid(3237970, 1, "869fc4d23152cb51db98af7544da6d7805cdecc88a24a7b125f22d38c328ca60") -- Bubsy 4D
addappid(3237971, 1, "451fa3287362f020a4a9730d7eb4672dd2a6c1933387b7dcffe79cc161fed8a1") -- Depot 3237971
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
