addappid(2361770) -- SHINOBI: Art of Vengeance
addappid(2361771,0,"6077dc2b1a88a7ae7a34470113e609a77bfc721374f4b17e20abc2f975ad2d85") -- Depot 1 (2361771_7116288504888504901.manifest)
