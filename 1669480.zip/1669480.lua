-- 1669480's Lua and Manifest Created by Morrenus
-- Firefighting Simulator: Ignite
-- Created: December 01, 2025 at 12:16:22 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 4 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1669480) -- Firefighting Simulator: Ignite
-- MAIN APP DEPOTS
addappid(1669481, 1, "86379ba94d829db600d16fb1a8228f1311045edc0905cd7f55c8e674028ce2e8") -- Depot 1669481
setManifestid(1669481, "3087249528632779765", 38815575634)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Firefighting Simulator Ignite - Rosenbauer HEROS Titan DLC  (AppID: 3544160)
addappid(3544160)
addappid(3544160, 1, "907cfcb846ccb3902d350463e48db5bb1b98ec8850923efc377194340541da16") -- Firefighting Simulator Ignite - Rosenbauer HEROS Titan DLC  - Depot 3544160
setManifestid(3544160, "8356537324760999203", 0)
-- Firefighting Simulator Ignite - Summer Camp DLC (AppID: 3544170)
addappid(3544170)
addappid(3544170, 1, "9996513aa6cad3d5710da64183e284b73b62ded8ef8e8ff593cfa67634592351") -- Firefighting Simulator Ignite - Summer Camp DLC - Depot 3544170
setManifestid(3544170, "420946172877143068", 0)
-- Firefighting Simulator Ignite - Fire Station Companion Pack (AppID: 3697660)
addappid(3697660)
addappid(3697660, 1, "7a1b1c50379f373233659c2752efbd243877e437a08464c12dd718be2496e83b") -- Firefighting Simulator Ignite - Fire Station Companion Pack - Depot 3697660
setManifestid(3697660, "7677613033911163998", 0)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3707380) -- Firefighting Simulator Ignite - Year 1 Season Pass
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3544180) -- Firefighting Simulator: Ignite - Parker's Story DLC (unreleased)