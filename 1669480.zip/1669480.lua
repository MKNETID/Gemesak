addappid(1669480) -- Firefighting Simulator: Ignite
addappid(1669481, 1, "86379ba94d829db600d16fb1a8228f1311045edc0905cd7f55c8e674028ce2e8") -- Depot 1669481
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3544160)
addappid(3544160, 1, "907cfcb846ccb3902d350463e48db5bb1b98ec8850923efc377194340541da16") -- Firefighting Simulator Ignite - Rosenbauer HEROS Titan DLC  - Depot 3544160
addappid(3544170)
addappid(3544170, 1, "9996513aa6cad3d5710da64183e284b73b62ded8ef8e8ff593cfa67634592351") -- Firefighting Simulator Ignite - Summer Camp DLC - Depot 3544170
addappid(3697660)
addappid(3697660, 1, "7a1b1c50379f373233659c2752efbd243877e437a08464c12dd718be2496e83b") -- Firefighting Simulator Ignite - Fire Station Companion Pack - Depot 3697660
addappid(3707380) -- Firefighting Simulator Ignite - Year 1 Season Pass
