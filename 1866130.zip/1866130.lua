addappid(1866130) -- Morbid Metal
addappid(1866131, 1, "9a7af3314bcdbbdffc8786b07b14c52230f77ae27ddc1479f060fca1b6c96d7f") -- Depot 1866131
