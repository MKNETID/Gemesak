addappid(2114970) -- Skinny & Franko: Fists of Violence
addappid(2114971,0,"e613e50b3155b7587c4ae7d2984574e70cae90c10afb44d053f708bc169639e6") -- Depot 1 (2114971_4822925154621377648.manifest)
