﻿addappid(2982610) -- Stonemachia
addappid(2982611, 1, "5b3a8947bbc1638151d9b638481bc36bbda6a1461545db5137147653ca5c95c5") -- Depot 2982611
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
