addappid(2754090)

addappid(2754091, 1, "e85bca1baec397ae81eb82e9f92147d42f0f361b72899b8b70cd2e2e16f3bbc5")

setManifestid(2754091, "6675577731697534894", 20570977137)

addappid(2906020)

addappid(3679010)

addappid(3679020)

addappid(3679030)

addappid(3679040)