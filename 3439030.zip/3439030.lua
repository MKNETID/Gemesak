addappid(3439030) -- The King Of Truancy
addappid(3439031,0,"96571fc504ae964f63a9b1c3df74bb1e9542111348e93c4fb95cae8edfda14d7") -- Depot 1 (3439031_1217577801825030751.manifest)
