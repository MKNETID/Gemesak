-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2289630 Manifest
-- Name: Shambles: Sons of the Apocalypse
-- Generated: 2025-06-28 08:34:03
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2289630) -- Shambles: Sons of the Apocalypse

-- MAIN APP DEPOTS
addappid(2289631, 1, "9d3133385abed6ebbee47e3729b0aeddaff1feda944d1302c6b544d5e6e0eb11") -- Depot 2289631
setManifestid(2289631, "4344184063608078470", 0)
