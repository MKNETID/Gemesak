addappid(2788950) -- Carrot Survivors
addappid(2788952, 1, "de0857f952b80a6773ed082d95f0e41c4d8ad16e3b30431e3f5fe3cff8ac6854") -- Depot 2788952
addappid(2788953, 1, "dafe00e8e8f001a8d305adfc6245cb45b3fa2d55029c40f1d7b830862c388db5") -- Depot 2788953
