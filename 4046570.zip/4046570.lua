addappid(4046570)
addappid(4046571,0,"53484f09327e4e6b15e32aa70c73a2b0cf99996636691ad8cbbcaa1404219372")
--setManifestid(4046571,"5877048327984983623")

--[[
This file belongs to Ahmeds Bot Discord Server]]--