-- Added with VTeam
-- AppID: 4006400

addappid(4006400)
addappid(4006401,0,"77849199dafe42edbd1cb0023c97c6d5f45a6a67ff936c0166cb87146e397446")
