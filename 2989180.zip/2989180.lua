addappid(2989180) -- Darwin's Paradox
addappid(2989181, 1, "51cd23f2f591d2786878933882bf37d6dc8887678b82a909dedae4a9ae6e4ebf") -- Depot 2989181
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(3990600) -- Darwin Pre-Order Skin Pack
