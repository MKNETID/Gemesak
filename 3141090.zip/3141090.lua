-- 3141090's Lua and Manifest Created by Morrenus
-- 100 Thailand Cats
-- Created: October 29, 2025 at 07:05:39 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3141090) -- 100 Thailand Cats
-- MAIN APP DEPOTS
addappid(3141091, 1, "b93ce9e503a205bf9857bbbe5cbcfe06e2e803dbd24abf55cd94f9a1cb95919c") -- Depot 3141091
setManifestid(3141091, "4207640200199281622", 374165371)
-- DLCS WITH DEDICATED DEPOTS
-- 100 Thailand Cats - Artbook (AppID: 3801920)
addappid(3801920)
addappid(3801920, 1, "3f00a03d50bdef90c922570630fb3a08a722d2b6f5be5f1b7ecad2113e3678e5") -- 100 Thailand Cats - Artbook - Depot 3801920
setManifestid(3801920, "8084322142800729900", 51831277)