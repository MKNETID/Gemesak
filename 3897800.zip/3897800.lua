addappid(3897800) -- Poker Night at the Inventory
addappid(3897801, 1, "31410dc657bdde34e7e0e1d71fb0c4786516d73d1624b7118505699610c987a4") -- Depot 3897801
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
