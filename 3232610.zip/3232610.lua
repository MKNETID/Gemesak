addappid(3232610) -- Bendy: Lone Wolf
addappid(3232611,0,"3df3f8133026f900fd7efef895cb3ed98ad3567c0ba2c9ed5992c881b264d51b") -- Depot 1 (3232611_8800088907046938262.manifest)
