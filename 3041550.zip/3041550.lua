﻿addappid(3041550) -- Electronic Market Simulator
addappid(3041552, 1, "ee46b744a6738298f0487b5d2fdd28238a2404a070e27754a32ae7651fe61a20") -- Depot 3041552
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
