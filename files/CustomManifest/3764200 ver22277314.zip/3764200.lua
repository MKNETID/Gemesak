-- First let's add all the appids!
addappid(3764200)
addappid(3990800)
addappid(3990820)

-- Coolio now let's add the decryption keys we need!
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist
addappid(3764201, 1, "bdf443ffde6449192b9863c0fa5e3cda31fdaa5e4d33e5bcded62dc2085b7cb8") -- Resident Evil Requiem (base)
addappid(3764203, 1, "b2e820287e6e3f32d1ccb3f2f8c95ec3783e8c0a75abab5d311a0a648626fd92") -- Resident Evil Requiem (base)
addappid(3990800, 1, "f5bf116706491176c9eee46a96fe1faa70b3f771d75ccb34f0c8962097a907e5") -- Resident Evil Requiem - Grace's Costume: Apocalypse
addappid(3990820, 1, "9ae4713cb4114effdd34d1cd54dbda8a560f27a05aef06fbaa0370748f69d15c") -- Resident Evil Requiem - Deluxe Kit

-- And last but not least, lock the depots to make shit work :3
setManifestid(228989, "3514306556860204959")
setManifestid(3764201, "9166256367562763038")
setManifestid(3764203, "651754783565368360")
setManifestid(3990800, "9181787779883827112")
setManifestid(3990820, "509708311968316285")
