﻿addappid(600520)
addappid(600521, 1, "24d0e3d688aa63f12673b4ddfea5a90946f5ec8c733aeaea0ce01d70a9b4139a")
