-- 3681810's Lua and Manifest Created by Morrenus
-- Blue Protocol: Star Resonance
-- Created: October 14, 2025 at 12:16:10 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3681810) -- Blue Protocol: Star Resonance
-- MAIN APP DEPOTS
addappid(3681812, 1, "93dc364cfd5230c092eea8b1ac3a6146af2f218a3f3ab806b4d9dd33d9d9cfe6") -- Depot 3681812
setManifestid(3681812, "1758826196141948767", 28339337104)