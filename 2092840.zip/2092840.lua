﻿addappid(2092840) -- The Occultist
addappid(2092841, 1, "5e4d0f245900061c32fbb61025c8bd3b4aa38919205b6fd83ba4ecadcdedcc83") -- Depot 2092841
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4012990)
addappid(4012990, 1, "048df12b5011da9da9abe27ac49ce45dc2545810c56653a3a066c1281fda6c76") -- The Occultist - Deluxe Upgrade Pack - Depot 4012990
